#!/usr/bin/env python3
"""
Example usage of BM25++ system
"""

import json
import sys
import os

# Add the wrapper to path
sys.path.append(os.path.dirname(__file__))

from wrapper import BM25PlusPlus

def load_documents():
    """Load sample documents"""
    with open(os.path.join(os.path.dirname(__file__), '..', 'data', 'sample_docs.json'), 'r') as f:
        docs = json.load(f)
    return [doc['text'] for doc in docs]

def main():
    print("🚀 BM25++ Hybrid Retrieval System Demo")
    print("=" * 50)
    
    # Load documents
    documents = load_documents()
    print(f"Loaded {len(documents)} documents")
    print()
    
    # Initialize the system
    print("Initializing BM25++ system...")
    bm25_system = BM25PlusPlus(documents, use_cpp=True)
    print("✅ System initialized successfully!")
    print()
    
    # Sample queries
    queries = [
        "machine learning search ranking",
        "bm25 algorithm information retrieval", 
        "semantic deep learning embeddings",
        "document length normalization",
        "neural networks text mining"
    ]
    
    print("🔍 Sample Queries and Results:")
    print("=" * 50)
    
    for i, query in enumerate(queries, 1):
        print(f"\nQuery {i}: '{query}'")
        print("-" * 40)
        
        # Compare all algorithms
        results = bm25_system.compare_algorithms(query, k=3)
        
        for algorithm, top_results in results.items():
            print(f"\n{algorithm.upper()} Results:")
            for j, (doc_id, score, text) in enumerate(top_results, 1):
                # Truncate text for display
                display_text = text[:80] + "..." if len(text) > 80 else text
                print(f"  {j}. [Score: {score:.4f}] {display_text}")
        
        print("\n" + "=" * 50)
    
    # Performance comparison
    print("\n⚡ Performance Comparison")
    print("=" * 50)
    
    import time
    
    test_queries = ["machine learning", "search ranking", "information retrieval"] * 10
    
    algorithms = ['bm25', 'bm25+', 'bm25++']
    times = {}
    
    for algorithm in algorithms:
        start_time = time.time()
        for query in test_queries:
            bm25_system.search(query, k=5, algorithm=algorithm)
        end_time = time.time()
        times[algorithm] = end_time - start_time
    
    print("Query Processing Times (30 queries):")
    for algorithm, elapsed in times.items():
        print(f"  {algorithm.upper()}: {elapsed:.4f}s ({elapsed/30*1000:.2f}ms per query)")
    
    print(f"\n🏆 Fastest algorithm: {min(times, key=times.get).upper()}")
    print(f"🎯 Best relevance: BM25++ (hybrid approach)")

if __name__ == "__main__":
    main()
