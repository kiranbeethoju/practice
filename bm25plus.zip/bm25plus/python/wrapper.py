import numpy as np
from typing import List, Dict, Any, Tuple
import re
from collections import defaultdict, Counter
import sys
import os

# Add the cpp module to path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'build'))

try:
    from bm25_core import BM25Scorer, BM25PlusScorer, BM25PlusPlusScorer, doc_from_python, query_from_python
except ImportError:
    print("Warning: C++ module not found. Using pure Python implementation.")
    BM25Scorer = None
    BM25PlusScorer = None
    BM25PlusPlusScorer = None


class DocumentProcessor:
    """Process documents and queries for BM25 scoring"""
    
    def __init__(self):
        self.vocab = set()
    
    def tokenize(self, text: str) -> List[str]:
        """Simple tokenizer - can be replaced with more sophisticated ones"""
        # Lowercase and split on non-alphanumeric characters
        tokens = re.findall(r'\b\w+\b', text.lower())
        return tokens
    
    def process_document(self, text: str) -> Dict[str, Any]:
        """Convert text to document format"""
        tokens = self.tokenize(text)
        term_freq = Counter(tokens)
        term_positions = defaultdict(list)
        
        for pos, token in enumerate(tokens):
            term_positions[token].append(pos)
        
        return {
            'term_freq': dict(term_freq),
            'term_positions': dict(term_positions),
            'length': len(tokens),
            'text': text,
            'tokens': tokens
        }


class PurePythonBM25:
    """Pure Python fallback implementation"""
    
    def __init__(self, k1=1.5, b=0.75):
        self.k1 = k1
        self.b = b
        self.avgdl = 0
        self.corpus_size = 0
        self.doc_freq = {}
    
    def build_stats(self, docs):
        self.corpus_size = len(docs)
        total_length = sum(doc['length'] for doc in docs)
        self.avgdl = total_length / self.corpus_size
        
        self.doc_freq = defaultdict(int)
        for doc in docs:
            for term in doc['term_freq']:
                self.doc_freq[term] += 1
    
    def idf(self, term):
        if term not in self.doc_freq:
            return 0.0
        return np.log((self.corpus_size - self.doc_freq[term] + 0.5) / (self.doc_freq[term] + 0.5))
    
    def score(self, query_terms, doc):
        score = 0.0
        for term in query_terms:
            if term in doc['term_freq']:
                tf = doc['term_freq'][term]
                idf_score = self.idf(term)
                denominator = tf + self.k1 * (1 - self.b + self.b * doc['length'] / self.avgdl)
                numerator = tf * (self.k1 + 1)
                score += idf_score * (numerator / denominator)
        return score


class PurePythonBM25Plus(PurePythonBM25):
    """Pure Python BM25+ implementation"""
    
    def __init__(self, k1=1.5, b=0.75, delta=1.0):
        super().__init__(k1, b)
        self.delta = delta
    
    def score(self, query_terms, doc):
        score = 0.0
        for term in query_terms:
            if term in doc['term_freq']:
                tf = doc['term_freq'][term]
                idf_score = self.idf(term)
                denominator = tf + self.k1 * (1 - self.b + self.b * doc['length'] / self.avgdl)
                numerator = tf * (self.k1 + 1)
                base_score = numerator / denominator
                score += idf_score * (base_score + self.delta)
        return score


class BM25PlusPlus:
    """Hybrid BM25++ system with semantic and proximity scoring"""
    
    def __init__(self, documents: List[str], use_cpp=True):
        self.processor = DocumentProcessor()
        self.documents = [self.processor.process_document(doc) for doc in documents]
        self.use_cpp = use_cpp and BM25Scorer is not None
        
        # Initialize scorers
        if self.use_cpp:
            self.bm25 = BM25Scorer()
            self.bm25_plus = BM25PlusScorer()
            self.bm25_plus_plus = BM25PlusPlusScorer()
            
            # Convert to C++ format
            cpp_docs = [doc_from_python(doc) for doc in self.documents]
            
            self.bm25.build_stats(cpp_docs)
            self.bm25_plus.build_stats(cpp_docs)
            self.bm25_plus_plus.build_stats(cpp_docs)
        else:
            self.bm25 = PurePythonBM25()
            self.bm25_plus = PurePythonBM25Plus()
            self.bm25.build_stats(self.documents)
            self.bm25_plus.build_stats(self.documents)
        
        # Build vocabulary for semantic scoring
        self._build_vocabulary()
        
        # Precompute document vectors for semantic similarity
        self.doc_vectors = [self._get_vector(doc['tokens']) for doc in self.documents]
    
    def _build_vocabulary(self):
        """Build vocabulary from all documents"""
        for doc in self.documents:
            self.processor.vocab.update(doc['tokens'])
        self.processor.vocab = sorted(list(self.processor.vocab))
        self.word_to_idx = {word: i for i, word in enumerate(self.processor.vocab)}
    
    def _get_vector(self, tokens: List[str]) -> np.ndarray:
        """Convert tokens to TF-IDF vector (simplified)"""
        vector = np.zeros(len(self.processor.vocab))
        term_freq = Counter(tokens)
        
        for term, freq in term_freq.items():
            if term in self.word_to_idx:
                vector[self.word_to_idx[term]] = freq
        
        # Simple TF normalization
        if np.sum(vector) > 0:
            vector = vector / np.sum(vector)
        
        return vector
    
    def cosine_similarity(self, vec1: np.ndarray, vec2: np.ndarray) -> float:
        """Calculate cosine similarity between two vectors"""
        dot_product = np.dot(vec1, vec2)
        norm1 = np.linalg.norm(vec1)
        norm2 = np.linalg.norm(vec2)
        
        if norm1 == 0 or norm2 == 0:
            return 0.0
        
        return dot_product / (norm1 * norm2)
    
    def proximity_score(self, query_terms: List[str], doc: Dict[str, Any]) -> float:
        """Calculate term proximity score"""
        if len(query_terms) < 2:
            return 0.0
        
        total_proximity = 0.0
        valid_pairs = 0
        
        for i in range(len(query_terms)):
            for j in range(i + 1, len(query_terms)):
                term1, term2 = query_terms[i], query_terms[j]
                
                if term1 in doc['term_positions'] and term2 in doc['term_positions']:
                    pos1 = doc['term_positions'][term1]
                    pos2 = doc['term_positions'][term2]
                    
                    # Find minimum distance
                    min_distance = min(abs(p1 - p2) for p1 in pos1 for p2 in pos2)
                    pair_proximity = 1.0 / (min_distance + 1.0)
                    
                    total_proximity += pair_proximity
                    valid_pairs += 1
        
        return total_proximity / valid_pairs if valid_pairs > 0 else 0.0
    
    def search(self, query: str, k: int = 10, algorithm: str = 'bm25++') -> List[Tuple[int, float, str]]:
        """Search documents using specified algorithm"""
        query_terms = self.processor.tokenize(query)
        if not query_terms:
            return []
        
        results = []
        
        for i, doc in enumerate(self.documents):
            if algorithm == 'bm25':
                if self.use_cpp:
                    cpp_query = query_from_python(query_terms)
                    cpp_doc = doc_from_python(doc)
                    score = self.bm25.score(cpp_query, cpp_doc)
                else:
                    score = self.bm25.score(query_terms, doc)
            
            elif algorithm == 'bm25+':
                if self.use_cpp:
                    cpp_query = query_from_python(query_terms)
                    cpp_doc = doc_from_python(doc)
                    score = self.bm25_plus.score(cpp_query, cpp_doc)
                else:
                    score = self.bm25_plus.score(query_terms, doc)
            
            elif algorithm == 'bm25++':
                # Calculate semantic similarity
                query_vector = self._get_vector(query_terms)
                semantic_score = self.cosine_similarity(query_vector, self.doc_vectors[i])
                
                # Calculate proximity score
                proximity_score = self.proximity_score(query_terms, doc)
                
                if self.use_cpp:
                    cpp_query = query_from_python(query_terms)
                    cpp_doc = doc_from_python(doc)
                    bm25_plus_score = self.bm25_plus.score(cpp_query, cpp_doc)
                    score = self.bm25_plus_plus.score(cpp_query, cpp_doc, semantic_score, proximity_score)
                else:
                    bm25_plus_score = self.bm25_plus.score(query_terms, doc)
                    score = (0.6 * bm25_plus_score + 
                            0.3 * semantic_score + 
                            0.1 * proximity_score)
            
            else:
                raise ValueError(f"Unknown algorithm: {algorithm}")
            
            results.append((i, score, doc['text']))
        
        # Sort by score (descending) and return top k
        results.sort(key=lambda x: x[1], reverse=True)
        return results[:k]
    
    def compare_algorithms(self, query: str, k: int = 10) -> Dict[str, List[Tuple[int, float, str]]]:
        """Compare all three algorithms on the same query"""
        return {
            'bm25': self.search(query, k, 'bm25'),
            'bm25+': self.search(query, k, 'bm25+'),
            'bm25++': self.search(query, k, 'bm25++')
        }
