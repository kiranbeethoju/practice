import sys
import os
from flask import Flask, render_template, request, jsonify
import qdrant_client
from qdrant_client.models import PointStruct, VectorParams, Distance, SparseVectorParams, SparseVector

sys.path.append(os.path.dirname(__file__))
from multidomain_bm25_plus_plus import MultiDomainBM25PlusPlus, tokenize

app = Flask(__name__)

# Global instances mapped per session
qdrant = qdrant_client.QdrantClient(":memory:")
bm25_model = None
vocab_idx = {}

col_bm25 = "bm25_search"
col_bm25_pp = "bm25pp_search"

def init_collections(dim):
    # Depending on the version, recreate_collection works or might need exception handling
    try:
        qdrant.delete_collection(col_bm25)
    except: pass
    try:
        qdrant.delete_collection(col_bm25_pp)
    except: pass
        
    qdrant.create_collection(
        collection_name=col_bm25,
        vectors_config={}, 
        sparse_vectors_config={"text": SparseVectorParams()}
    )
    qdrant.create_collection(
        collection_name=col_bm25_pp,
        vectors_config=VectorParams(size=dim, distance=Distance.COSINE)
    )

def get_bm25_sparse_doc(doc_idx):
    if not bm25_model: return SparseVector(indices=[], values=[])
    doc = bm25_model._proc[doc_idx]
    indices, values = [], []
    for t in doc["tf"]:
        if t in vocab_idx:
            tf = doc["tf"][t]
            idf = bm25_model.idf.get(t, 0.0)
            num = tf * (bm25_model.k1 + 1.0)
            den = tf + bm25_model.k1 * (1.0 - bm25_model.b + bm25_model.b * doc["len"] / bm25_model.avgdl)
            val = idf * (num / den)
            indices.append(vocab_idx[t])
            values.append(val)
    return SparseVector(indices=indices, values=values)

def get_bm25_sparse_query(query):
    toks = tokenize(query)
    indices, values = [], []
    for t in toks:
        if t in vocab_idx:
            indices.append(vocab_idx[t])
            values.append(1.0)
    return SparseVector(indices=indices, values=values)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/embed", methods=["POST"])
def embed():
    global bm25_model, vocab_idx
    text_data = request.json.get("text", "")
    
    # Parse sentences handling empty lines
    sentences = [s.strip() for s in text_data.split("\n") if len(s.strip()) > 5]
    if not sentences:
        return jsonify({"error": "No valid sentences provided."}), 400

    bm25_model = MultiDomainBM25PlusPlus(sentences)
    
    vocab = set()
    for d in bm25_model._proc:
        vocab.update(d["tf"].keys())
    vocab_idx = {t: i for i, t in enumerate(sorted(list(vocab)))}
    
    init_collections(bm25_model.emb.DIM)
    
    points_b = []
    points_c = []
    
    for i, doc_text in enumerate(sentences):
        sv = get_bm25_sparse_doc(i)
        points_b.append(PointStruct(id=i, vector={"text": sv}, payload={"text": doc_text}))
        
        dv = bm25_model.emb.encode(doc_text).tolist()
        points_c.append(PointStruct(id=i, vector=dv, payload={"text": doc_text}))
        
    qdrant.upsert(collection_name=col_bm25, points=points_b)
    qdrant.upsert(collection_name=col_bm25_pp, points=points_c)
    
    return jsonify({"success": True, "count": len(sentences)})

@app.route("/search", methods=["POST"])
def search():
    if not bm25_model:
        return jsonify({"error": "No data embedded yet! Please embed sentences first."}), 400
        
    query = request.json.get("query", "").strip()
    if not query:
        return jsonify({"error": "Empty query"}), 400

    # Execute sparse search
    res_b = qdrant.query_points(
        collection_name=col_bm25,
        query=get_bm25_sparse_query(query),
        using="text",
        limit=5
    )
    
    # Execute dense search
    res_c = qdrant.query_points(
        collection_name=col_bm25_pp,
        query=bm25_model.emb.encode(query).tolist(),
        limit=5
    )
    
    # Calculate practical maximum BM25 score for realistic normalization
    query_toks = tokenize(query)
    max_bm25_score = 0.0
    for t in query_toks:
        if t in vocab_idx:
            # A realistic excellent match (tf=1, length=avgdl) roughly equals the IDF.
            max_bm25_score += bm25_model.idf.get(t, 0.0)
    
    # Give it a slight padding so an exactly average doc scores ~0.95 instead of artificially hitting 1.0 exactly
    max_bm25_score = max_bm25_score * 1.1 
    
    if max_bm25_score == 0.0:
        max_bm25_score = 1.0 # Prevent division by zero
    
    # Format results, mapping BM25 realistically to a uniform -1.0 to 1.0 scale
    def scale_bm25(score):
        normalized = min(1.0, score / max_bm25_score)
        return (normalized * 2.0) - 1.0
        
    bm25_h = [{"score": scale_bm25(h.score), "text": h.payload["text"]} for h in res_b.points]
    bm25pp_h = [{"score": h.score, "text": h.payload["text"]} for h in res_c.points]
    
    return jsonify({"success": True, "bm25": bm25_h, "bm25pp": bm25pp_h})

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8923, debug=False)
