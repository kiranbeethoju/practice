# BM25 Algorithm Efficiency HTML Demo

This directory contains scripts to generate and view HTML reports comparing BM25, BM25+, and BM25++ algorithms.

## Files

- **`efficiency_demo_html.py`** - Main script that generates comprehensive HTML reports
- **`efficiency_demo_results.html`** - Generated HTML report (after running the demo)
- **`view_results.py`** - Helper script to open HTML results in default browser
- **`efficiency_demo.py`** - Original console-based demo script

## Usage

### Generate HTML Report

```bash
python3 efficiency_demo_html.py
```

This will:
- Run comprehensive tests on BM25, BM25+, and BM25++ algorithms
- Collect speed, effectiveness, and bias reduction data
- Generate a styled HTML report with tables and visual indicators
- Save results as `efficiency_demo_results.html`

### View Results

```bash
python3 view_results.py
```

Or simply open `efficiency_demo_results.html` in your web browser.

## HTML Report Features

The generated HTML report includes:

### 📊 Summary Statistics
- Overview cards showing key metrics
- Algorithm comparison table
- Performance indicators

### ⚡ Speed Efficiency Comparison
- Side-by-side speed measurements
- Average query times in milliseconds
- Speed ratings (FAST/MEDIUM/SLOW)
- Color-coded performance indicators

### 🎯 Length Bias Demonstration
- Comparison of BM25 vs BM25+ length bias
- Document categorization (SHORT/MEDIUM/LONG)
- Score analysis across document lengths
- Visual highlighting of bias reduction

### 🎯 Effectiveness Comparison
- Test case results for different query types
- Semantic vs technical query performance
- Ranking accuracy across algorithms
- Document preview with scores

### 🔗 Hybrid Scoring Breakdown
- BM25++ component analysis
- Semantic boost indicators
- Length factor analysis
- Detailed scoring breakdown

## Visual Features

- **Responsive Design**: Works on desktop and mobile
- **Color Coding**: 
  - Green for fast/ optimal performance
  - Orange for medium performance
  - Red for slow/ suboptimal performance
- **Interactive Tables**: Hover effects and highlighting
- **Algorithm-specific Styling**: Different background colors for each algorithm
- **Professional Layout**: Clean, modern design with proper typography

## Test Data

The demo uses a curated corpus of:
- **5 short documents** (focused, concise content)
- **3 medium documents** (detailed explanations)
- **2 long documents** (comprehensive coverage)

Test queries include:
- Simple queries: "machine learning"
- Medium complexity: "information retrieval"
- Complex queries: "semantic search ranking"
- Technical queries: "bm25 algorithm optimization"

## Performance Metrics

- **100 runs per query** for accurate speed measurements
- **Multiple query types** to test different scenarios
- **Statistical analysis** with mean values
- **Comparative analysis** across all algorithms

## Browser Compatibility

The HTML report is compatible with:
- Chrome/Chromium (recommended)
- Firefox
- Safari
- Edge

## Troubleshooting

### C++ Module Not Found
If you see "Warning: C++ module not found. Using pure Python implementation.", the demo will still work but may run slower. This is normal if the C++ extension isn't compiled.

### HTML File Not Found
Ensure you run `efficiency_demo_html.py` before trying to view results.

### Browser Not Opening
If `view_results.py` doesn't open your browser, manually open the HTML file:
```bash
# macOS
open efficiency_demo_results.html

# Linux
xdg-open efficiency_demo_results.html

# Windows
start efficiency_demo_results.html
```
