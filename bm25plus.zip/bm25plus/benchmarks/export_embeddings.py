#!/usr/bin/env python3
"""
Multi-Domain Embeddings Vector DB Interface
-------------------------------------------
This script demonstrates how to export and use the `MultiDomainEmbeddings` 
model individually to generate vectors for a text collection and then 
query that vector embedding space.

You can import `MultiDomainEmbeddings` directly anywhere in your backend 
to power standalone Vector DB operations.
"""

import sys, os
import numpy as np

# Make sure we can import from the benchmarks folder
sys.path.append(os.path.join(os.path.dirname(__file__)))
from multidomain_bm25_plus_plus import MultiDomainEmbeddings

class VectorDatabaseStub:
    """A simulated in-memory vector database."""
    def __init__(self, embed_model):
        self.model = embed_model
        self.documents = []
        self.embeddings = []

    def add_collection(self, docs):
        print(f"Adding {len(docs)} documents to collection... ", end="", flush=True)
        # We can ask the model to efficiently encode a whole batch of documents
        vectors = self.model.encode_batch(docs)
        self.documents.extend(docs)
        self.embeddings.extend(vectors)
        print("Done!")

    def query(self, search_text, top_k=3):
        print(f"\n🔍 Querying Vector Database for: '{search_text}'")
        
        # 1. Convert user search text into an embedding query vector
        query_vector = self.model.encode(search_text)
        
        # 2. Compare the query vector against all document vectors
        results = []
        for doc_id, doc_vector in enumerate(self.embeddings):
            # We use Cosine Similarity implemented natively in the embedding class
            score = self.model.cosine(query_vector, doc_vector)
            results.append((doc_id, score, self.documents[doc_id]))

        # Sort by best-matching (highest cosine similarity score)
        results.sort(key=lambda x: x[1], reverse=True)

        for rank, (doc_id, score, doc) in enumerate(results[:top_k], 1):
            print(f"   {rank}. [Score: {score:.3f}] - {doc}")
            
        return results[:top_k]

if __name__ == "__main__":
    print("="*60)
    print(" 🛠 Embeddings Export & Vector Database Demonstration")
    print("="*60)
    
    # 1. Initialize the Standalone Embedding Model
    print("Initializing MultiDomainEmbeddings Model...")
    embedding_model = MultiDomainEmbeddings()
    print(f"Emitting vectors with {embedding_model.DIM} Dimensions.\n")

    # 2. Initialize our simulated Vector DB
    db = VectorDatabaseStub(embed_model=embedding_model)

    # 3. Create a collection with multi-domain data
    sample_collection = [
        "Record-breaking heatwave attributed to climate change.",
        "Robot vacuum cleaner LiDAR mapping auto-empty base.",
        "Deep learning convolutional neural network evaluation.",
        "Wireless noise-cancelling headphones with long battery life.",
        "Patient presents with acute myocardial infarction chest pain."
    ]
    db.add_collection(sample_collection)

    # 4. Perform vector similarity searches
    db.query("artificial intelligence models and neural nets")
    db.query("what is the best machine to clean floors by itself?")
    db.query("symptoms of a severe cardiac heart event")
    print("\n✅ Successfully used MultiDomainEmbeddings as a standalone Vector Model!")
