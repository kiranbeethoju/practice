#!/usr/bin/env python3
import sys
import os
import qdrant_client
from qdrant_client.models import PointStruct, VectorParams, Distance, SparseVectorParams, SparseVector

sys.path.append(os.path.join(os.path.dirname(__file__)))
from multidomain_bm25_plus_plus import MultiDomainBM25PlusPlus, MultiDomainEmbeddings, make_corpus, tokenize

print("Initializing local Qdrant...")
# Try memory first
qdrant = qdrant_client.QdrantClient(":memory:")

print("Loading documents from domains...")
corpus = make_corpus()
all_docs = []
for domain, docs in corpus.items():
    all_docs.extend(docs)

print(f"Loaded {len(all_docs)} documents.")

# Initialize the BM25++ algorithm to get vocabulary and stats
bm25_baseline = MultiDomainBM25PlusPlus(all_docs)

# Build a vocabulary index for sparse vectors
vocab = set()
for d in bm25_baseline._proc:
    vocab.update(d["tf"].keys())
vocab = sorted(list(vocab))
token_to_idx = {t: i for i, t in enumerate(vocab)}

def get_bm25_sparse_doc(doc_idx):
    doc = bm25_baseline._proc[doc_idx]
    indices = []
    values = []
    for t in doc["tf"]:
        if t in token_to_idx:
            tf = doc["tf"][t]
            idf = bm25_baseline.idf.get(t, 0.0)
            # standard bm25 scoring
            num = tf * (bm25_baseline.k1 + 1.0)
            den = tf + bm25_baseline.k1 * (1.0 - bm25_baseline.b + bm25_baseline.b * doc["len"] / bm25_baseline.avgdl)
            val = idf * (num / den)
            indices.append(token_to_idx[t])
            values.append(val)
    return SparseVector(indices=indices, values=values)

def get_bm25_sparse_query(query):
    toks = tokenize(query)
    indices = []
    values = []
    for t in toks:
        if t in token_to_idx:
            indices.append(token_to_idx[t])
            values.append(1.0)
    return SparseVector(indices=indices, values=values)

# Setup Collections in Local Qdrant
col_bm25 = "bm25_collection"
col_bm25_pp = "bm25_plus_plus_collection"

print("Creating BM25 Collection in Qdrant (Sparse Vectors)...")
qdrant.create_collection(
    collection_name=col_bm25,
    vectors_config={}, # no dense vectors
    sparse_vectors_config={"text": SparseVectorParams()}
)

print("Creating BM25++ Embeddings Collection in Qdrant (Dense Vectors)...")
# For BM25++ we use the standalone embedding model as requested
embed_model = MultiDomainBM25PlusPlus(all_docs).emb
qdrant.create_collection(
    collection_name=col_bm25_pp,
    vectors_config=VectorParams(size=embed_model.DIM, distance=Distance.COSINE)
)

print("Uploading documents to Qdrant...")
points_bm25 = []
points_bm25_pp = []

for i, doc_text in enumerate(all_docs):
    sparse_vec = get_bm25_sparse_doc(i)
    # BM25 collection uses sparse vector
    points_bm25.append(PointStruct(id=i, vector={"text": sparse_vec}, payload={"text": doc_text}))
    
    # BM25++ collection uses dense embeddings
    dense_vec = embed_model.encode(doc_text).tolist()
    points_bm25_pp.append(PointStruct(id=i, vector=dense_vec, payload={"text": doc_text}))

qdrant.upsert(collection_name=col_bm25, points=points_bm25)
qdrant.upsert(collection_name=col_bm25_pp, points=points_bm25_pp)
print("Data ingested successfully.\n")

# Run some comparison searches
queries = [
    "what is the best machine to clean floors by itself?",
    "artificial intelligence models and neural nets",
    "symptoms of a severe cardiac heart event",
    "litigation due to defective product causing injury"
]

for q in queries:
    print("=" * 80)
    print(f"🔍 SEARCH QUERY: '{q}'")
    print("=" * 80)

    # BM25 Search
    print("\n[ 1 ] Standard BM25 Results")
    sparse_q = get_bm25_sparse_query(q)
    res_bm25 = qdrant.query_points(
        collection_name=col_bm25,
        query=sparse_q,
        using="text",
        limit=2
    )
    for hit in res_bm25.points:
        print(f"  -> Score: {hit.score:.3f} | {hit.payload['text']}")

    # BM25++ Embeddings Search
    print("\n[ 2 ] BM25++ Embeddings Results")
    dense_q = embed_model.encode(q).tolist()
    res_bm25_pp = qdrant.query_points(
        collection_name=col_bm25_pp,
        query=dense_q,
        limit=2
    )
    for hit in res_bm25_pp.points:
        print(f"  -> Score: {hit.score:.3f} | {hit.payload['text']}")
    print("\n")

print("Completed!")
