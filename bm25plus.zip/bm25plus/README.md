# BM25++ Hybrid Retrieval System

A high-performance document ranking system implementing BM25, BM25+, and the novel BM25++ hybrid algorithm with semantic and proximity scoring.

## 🚀 Features

- **BM25**: Classic probabilistic ranking algorithm
- **BM25+**: Improved version with reduced long-document bias
- **BM25++**: Hybrid approach combining:
  - BM25+ scoring (60% weight)
  - Semantic similarity (30% weight) 
  - Term proximity scoring (10% weight)
- **C++ Backend**: High-performance scoring engine
- **Python Interface**: User-friendly API with fallback pure Python implementation
- **Comprehensive Benchmarks**: Performance and accuracy comparisons

## 📁 Project Structure

```
bm25plus/
├── cpp/                    # C++ core engine
│   ├── scorer.h           # Core data structures and classes
│   ├── bm25.cpp           # BM25 implementation
│   ├── bm25_plus.cpp      # BM25+ implementation
│   ├── bm25_plus_plus.cpp # BM25++ implementation
│   └── bindings.cpp       # Python bindings (pybind11)
├── python/                # Python interface
│   ├── wrapper.py         # Main API wrapper
│   └── example.py         # Usage examples
├── data/                  # Sample data
│   └── sample_docs.json   # Sample documents
├── benchmarks/            # Performance testing
│   └── benchmark.py       # Comprehensive benchmark suite
├── CMakeLists.txt         # Build configuration
└── README.md             # This file
```

## 🛠️ Installation

### Prerequisites

```bash
# Python dependencies
pip install numpy matplotlib

# For C++ build (macOS)
brew install cmake pybind11

# For C++ build (Ubuntu/Debian)
sudo apt-get install cmake python3-dev pybind11-dev
```

### Building the C++ Module

```bash
# Create build directory
mkdir build
cd build

# Configure and build
cmake ..
make

# The compiled module will be in build/bm25_core.so
```

## 🎯 Quick Start

```python
from python.wrapper import BM25PlusPlus
import json

# Load sample documents
with open('data/sample_docs.json', 'r') as f:
    docs = json.load(f)
documents = [doc['text'] for doc in docs]

# Initialize the system
bm25_system = BM25PlusPlus(documents)

# Search using different algorithms
results = bm25_system.search("machine learning", k=5, algorithm='bm25++')

# Compare all algorithms
comparison = bm25_system.compare_algorithms("search ranking", k=3)
```

## 📊 Algorithms

### BM25 (Baseline)
Classic probabilistic ranking with TF normalization:
```
score(q, d) = Σ IDF(t) * ((tf * (k1 + 1)) / (tf + k1 * (1 - b + b * dl/avgdl)))
```

### BM25+ (Improved)
Adds delta constant to reduce long-document bias:
```
score(q, d) = Σ IDF(t) * (((tf * (k1 + 1)) / (tf + k1 * (1 - b + b * dl/avgdl))) + δ)
```

### BM25++ (Hybrid)
Combines multiple relevance signals:
```
final_score = w1 * bm25_plus + w2 * semantic_similarity + w3 * proximity_score
```

## 🏃‍♂️ Running Benchmarks

```bash
# Run comprehensive benchmark suite
cd benchmarks
python benchmark.py

# Run basic example
cd python
python example.py
```

### Expected Results

| Algorithm | Speed | Accuracy | Notes |
|-----------|-------|----------|-------|
| BM25      | ⭐⭐⭐⭐ | ⭐⭐⭐ | Fast but keyword-only |
| BM25+     | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | Better length normalization |
| BM25++    | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ | Best relevance |

## 🧪 Example Usage

```python
# Initialize with documents
documents = [
    "Machine learning improves search ranking",
    "BM25 is a ranking algorithm", 
    "Deep learning enhances semantic search"
]

system = BM25PlusPlus(documents)

# Single algorithm search
results = system.search("machine learning", k=3, algorithm='bm25++')

# Compare all algorithms
comparison = system.compare_algorithms("search ranking")

for algorithm, top_results in comparison.items():
    print(f"\n{algorithm.upper()} Results:")
    for doc_id, score, text in top_results:
        print(f"  Score: {score:.4f} - {text}")
```

## 🔧 Configuration

### Algorithm Parameters

```python
# Access and modify parameters
system = BM25PlusPlus(documents)

# BM25 parameters
system.bm25.k1 = 1.5
system.bm25.b = 0.75

# BM25+ parameters  
system.bm25_plus.delta = 1.0

# BM25++ weights
system.bm25_plus_plus.w1 = 0.6  # BM25+ weight
system.bm25_plus_plus.w2 = 0.3  # semantic weight
system.bm25_plus_plus.w3 = 0.1  # proximity weight
```

## 📈 Performance

The system is optimized for:
- **Speed**: C++ core with SIMD-friendly operations
- **Memory**: Efficient data structures and minimal copying
- **Scalability**: Parallel processing support with OpenMP
- **Flexibility**: Pure Python fallback when C++ unavailable

## 🎯 Use Cases

- **Search Engines**: Core ranking component
- **RAG Pipelines**: Document retrieval for LLMs
- **Recommendation Systems**: Content-based filtering
- **Information Retrieval**: Academic and enterprise search
- **Document Similarity**: Semantic matching applications

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Ensure benchmarks pass
5. Submit a pull request

## 📄 License

This project is open source. See LICENSE file for details.

## 🔮 Future Enhancements

- [ ] FAISS integration for ANN search
- [ ] Advanced query expansion
- [ ] Learning-to-rank layer
- [ ] Distributed processing support
- [ ] Real-time indexing
- [ ] Custom embedding models
