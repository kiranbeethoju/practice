#include "scorer.h"
#include <cmath>

void BM25PlusScorer::build_stats(const std::vector<Document>& docs) {
    corpus_size = docs.size();
    avgdl = 0.0f;
    
    // Calculate average document length
    for (const auto& doc : docs) {
        avgdl += doc.length;
    }
    avgdl /= corpus_size;
    
    // Calculate document frequency for each term
    doc_freq.clear();
    for (const auto& doc : docs) {
        for (const auto& term_pair : doc.term_freq) {
            const std::string& term = term_pair.first;
            doc_freq[term]++;
        }
    }
}

float BM25PlusScorer::idf(const std::string& term) const {
    auto it = doc_freq.find(term);
    if (it == doc_freq.end()) {
        return 0.0f;
    }
    
    return std::log((corpus_size - it->second + 0.5f) / (it->second + 0.5f));
}

float BM25PlusScorer::score(const QueryInfo& query, const Document& doc) const {
    float total_score = 0.0f;
    
    for (const std::string& term : query.terms) {
        auto tf_it = doc.term_freq.find(term);
        if (tf_it == doc.term_freq.end()) {
            continue;  // term not in document
        }
        
        int tf = tf_it->second;
        float idf_score = idf(term);
        
        // BM25+ formula: adds delta to reduce long-document bias
        float denominator = tf + k1 * (1.0f - b + b * doc.length / avgdl);
        float numerator = tf * (k1 + 1.0f);
        float base_score = numerator / denominator;
        
        float term_score = idf_score * (base_score + delta);
        total_score += term_score;
    }
    
    return total_score;
}
