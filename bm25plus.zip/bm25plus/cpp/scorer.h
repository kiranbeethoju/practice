#pragma once
#include <vector>
#include <string>
#include <unordered_map>
#include <map>

struct Document {
    std::unordered_map<std::string, int> term_freq;
    int length;
    std::unordered_map<std::string, std::vector<int>> term_positions;
};

struct QueryInfo {
    std::vector<std::string> terms;
    std::unordered_map<std::string, int> term_freq;
};

class BM25Scorer {
public:
    float k1 = 1.5;
    float b = 0.75;
    float avgdl;
    int corpus_size;
    std::unordered_map<std::string, int> doc_freq;
    
    BM25Scorer() = default;
    
    void build_stats(const std::vector<Document>& docs);
    float idf(const std::string& term) const;
    float score(const QueryInfo& query, const Document& doc) const;
};

class BM25PlusScorer {
public:
    float k1 = 1.5;
    float b = 0.75;
    float delta = 1.0;
    float avgdl;
    int corpus_size;
    std::unordered_map<std::string, int> doc_freq;
    
    BM25PlusScorer() = default;
    
    void build_stats(const std::vector<Document>& docs);
    float idf(const std::string& term) const;
    float score(const QueryInfo& query, const Document& doc) const;
};

class BM25PlusPlusScorer {
public:
    float w1 = 0.6;  // BM25+ weight
    float w2 = 0.3;  // semantic weight
    float w3 = 0.1;  // proximity weight
    
    BM25PlusScorer bm25_plus;
    
    void build_stats(const std::vector<Document>& docs);
    float score(const QueryInfo& query, const Document& doc, 
                float semantic_score = 0.0f, float proximity_score = 0.0f) const;
    float proximity_score(const QueryInfo& query, const Document& doc) const;
};
