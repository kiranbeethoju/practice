#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <pybind11/numpy.h>
#include "scorer.h"

namespace py = pybind11;

// Helper function to convert Python document format to C++ Document struct
Document doc_from_python(const py::dict& doc_dict) {
    Document doc;
    py::dict term_freq_dict = doc_dict["term_freq"].cast<py::dict>();
    py::list term_positions_dict = doc_dict["term_positions"].cast<py::dict>();
    
    for (auto item : term_freq_dict) {
        std::string term = item.first.cast<std::string>();
        int freq = item.second.cast<int>();
        doc.term_freq[term] = freq;
    }
    
    for (auto item : term_positions_dict) {
        std::string term = item.first.cast<std::string>();
        py::list positions = item.second.cast<py::list>();
        std::vector<int> pos_vec;
        for (auto pos : positions) {
            pos_vec.push_back(pos.cast<int>());
        }
        doc.term_positions[term] = pos_vec;
    }
    
    doc.length = doc_dict["length"].cast<int>();
    return doc;
}

QueryInfo query_from_python(const py::list& query_terms) {
    QueryInfo query;
    for (auto term : query_terms) {
        std::string term_str = term.cast<std::string>();
        query.terms.push_back(term_str);
        query.term_freq[term_str]++;
    }
    return query;
}

PYBIND11_MODULE(bm25_core, m) {
    m.doc() = "BM25, BM25+, and BM25++ scoring engine";
    
    py::class_<Document>(m, "Document")
        .def(py::init<>());
    
    py::class_<QueryInfo>(m, "QueryInfo")
        .def(py::init<>());
    
    py::class_<BM25Scorer>(m, "BM25Scorer")
        .def(py::init<>())
        .def("build_stats", &BM25Scorer::build_stats)
        .def("idf", &BM25Scorer::idf)
        .def("score", &BM25Scorer::score)
        .def_readwrite("k1", &BM25Scorer::k1)
        .def_readwrite("b", &BM25Scorer::b)
        .def_readwrite("avgdl", &BM25Scorer::avgdl)
        .def_readwrite("corpus_size", &BM25Scorer::corpus_size);
    
    py::class_<BM25PlusScorer>(m, "BM25PlusScorer")
        .def(py::init<>())
        .def("build_stats", &BM25PlusScorer::build_stats)
        .def("idf", &BM25PlusScorer::idf)
        .def("score", &BM25PlusScorer::score)
        .def_readwrite("k1", &BM25PlusScorer::k1)
        .def_readwrite("b", &BM25PlusScorer::b)
        .def_readwrite("delta", &BM25PlusScorer::delta)
        .def_readwrite("avgdl", &BM25PlusScorer::avgdl)
        .def_readwrite("corpus_size", &BM25PlusScorer::corpus_size);
    
    py::class_<BM25PlusPlusScorer>(m, "BM25PlusPlusScorer")
        .def(py::init<>())
        .def("build_stats", &BM25PlusPlusScorer::build_stats)
        .def("score", &BM25PlusPlusScorer::score)
        .def("proximity_score", &BM25PlusPlusScorer::proximity_score)
        .def_readwrite("w1", &BM25PlusPlusScorer::w1)
        .def_readwrite("w2", &BM25PlusPlusScorer::w2)
        .def_readwrite("w3", &BM25PlusPlusScorer::w3);
    
    // Convenience functions for Python integration
    m.def("doc_from_python", &doc_from_python);
    m.def("query_from_python", &query_from_python);
}
