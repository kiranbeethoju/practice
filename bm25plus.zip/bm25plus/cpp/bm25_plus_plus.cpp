#include "scorer.h"
#include <cmath>
#include <algorithm>
#include <climits>

void BM25PlusPlusScorer::build_stats(const std::vector<Document>& docs) {
    bm25_plus.build_stats(docs);
}

float BM25PlusPlusScorer::score(const QueryInfo& query, const Document& doc,
                               float semantic_score, float proximity_score) const {
    float bm25_plus_score = bm25_plus.score(query, doc);
    
    // Hybrid scoring combining BM25+, semantic similarity, and proximity
    return w1 * bm25_plus_score + w2 * semantic_score + w3 * proximity_score;
}

float BM25PlusPlusScorer::proximity_score(const QueryInfo& query, const Document& doc) const {
    if (query.terms.size() < 2) {
        return 0.0f;
    }
    
    float total_proximity = 0.0f;
    int valid_pairs = 0;
    
    // Calculate proximity for each pair of query terms
    for (size_t i = 0; i < query.terms.size(); ++i) {
        for (size_t j = i + 1; j < query.terms.size(); ++j) {
            const std::string& term1 = query.terms[i];
            const std::string& term2 = query.terms[j];
            
            auto pos1_it = doc.term_positions.find(term1);
            auto pos2_it = doc.term_positions.find(term2);
            
            if (pos1_it != doc.term_positions.end() && pos2_it != doc.term_positions.end()) {
                const std::vector<int>& pos1 = pos1_it->second;
                const std::vector<int>& pos2 = pos2_it->second;
                
                // Find minimum distance between any occurrence of term1 and term2
                int min_distance = INT_MAX;
                for (int p1 : pos1) {
                    for (int p2 : pos2) {
                        int distance = std::abs(p1 - p2);
                        min_distance = std::min(min_distance, distance);
                    }
                }
                
                if (min_distance != INT_MAX) {
                    // Convert distance to proximity score (closer = higher score)
                    float pair_proximity = 1.0f / (min_distance + 1.0f);
                    total_proximity += pair_proximity;
                    valid_pairs++;
                }
            }
        }
    }
    
    if (valid_pairs == 0) {
        return 0.0f;
    }
    
    return total_proximity / valid_pairs;
}
