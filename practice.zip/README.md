# Medical Symptom Intake & Triage System

An AI-powered dynamic medical symptom checker built with Flask, Azure OpenAI/OpenAI API, and a modern chat interface with clickable response buttons.

## Features

- **Dynamic Question Generation**: AI asks relevant follow-up questions based on patient responses
- **Clickable Response Buttons**: Easy-to-use button options (severity, duration, yes/no, etc.)
- **Custom Input Support**: Users can type detailed answers when buttons don't fit
- **Red Flag Detection**: Automatic detection of urgent symptoms requiring immediate care
- **Configurable Thresholds**:
  - Max questions limit (prevents infinite loops)
  - Confidence threshold (stops when diagnosis is confident enough)
- **Session Management**: Tracks conversation history and prevents repeated questions
- **Differential Diagnosis**: Shows multiple possible conditions with confidence scores
- **Triage Level**: Categorizes as routine, urgent, or emergency
- **Demo Mode**: Works without API keys for testing UI

## Architecture

```
Frontend (HTML/JS with clickable buttons)
    ↓
Flask API
    ↓
Conversation Engine (State Machine)
    ↓
Azure OpenAI / OpenAI API (Question Generation)
    ↓
SQLite Database (Session & Answer Storage)
```

---

# Quick Start Guide

## Prerequisites

- Python 3.8 or higher
- pip (Python package manager)
- (Optional) Azure OpenAI or OpenAI API key for real AI responses

## Installation & Setup

### Step 1: Install Dependencies

Open your terminal and navigate to the project directory:

```bash
cd /Users/kiran/Documents/intskeFormAI
pip3 install -r requirements.txt
```

This will install:
- Flask (web framework)
- Flask-SQLAlchemy (database)
- openai (AI SDK)
- python-dotenv (environment variables)

### Step 2: Configure AI API (Choose One Option)

#### Option A: Demo Mode (No API Key Required)

The app works in **demo mode** out of the box with hardcoded mock questions. Great for testing the UI!

```bash
# Just run the app - no configuration needed
python3 app.py
```

**Demo mode limitations:**
- Questions are pre-written, not AI-generated
- Same questions every time
- No real medical intelligence
- For UI testing only

---

#### Option B: Azure OpenAI (Recommended for Enterprise)

1. **Create Azure OpenAI Resource:**
   - Go to [Azure Portal](https://portal.azure.com)
   - Search for "Azure OpenAI"
   - Click "Create" and fill in the details
   - Select a region (e.g., East US, West Europe)
   - Choose pricing tier (Standard S0)

2. **Deploy a Model:**
   - In your Azure OpenAI resource, go to "Deployments"
   - Click "Create deployment"
   - Select model: `gpt-4` or `gpt-35-turbo`
   - Give it a name (e.g., `gpt-4`)
   - Click "Create"

3. **Get Your Credentials:**
   - Go to "Keys and Endpoint" in your Azure OpenAI resource
   - Copy the API Key
   - Copy the Endpoint URL

4. **Configure `.env` File:**

```bash
# Copy the example file
cp .env.example .env
```

Edit `.env` with your credentials:

```env
# Azure OpenAI Configuration
AZURE_OPENAI_API_KEY=your_actual_api_key_here
AZURE_OPENAI_ENDPOINT=https://your-resource-name.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT=gpt-4
AZURE_OPENAI_API_VERSION=2024-02-15-preview

# Flask Configuration
SECRET_KEY=change-this-to-random-string
```

---

#### Option C: OpenAI API (Simpler, Non-Azure)

If you don't have Azure, you can use OpenAI's API directly:

1. **Get OpenAI API Key:**
   - Go to [https://platform.openai.com/api-keys](https://platform.openai.com/api-keys)
   - Create an account or sign in
   - Click "Create new secret key"
   - Copy the key (starts with `sk-...`)

2. **Update `.env` File:**

```env
# OpenAI Configuration (Non-Azure)
AZURE_OPENAI_API_KEY=sk-your-actual-openai-key-here
AZURE_OPENAI_ENDPOINT=https://api.openai.com/v1
AZURE_OPENAI_DEPLOYMENT=gpt-4
AZURE_OPENAI_API_VERSION=2024-02-15-preview

# Flask Configuration
SECRET_KEY=change-this-to-random-string
```

### Step 3: Run the Application

```bash
python3 app.py
```

You should see:
```
* Serving Flask app 'app'
* Running on http://127.0.0.1:5000
* Press CTRL+C to quit
```

### Step 4: Open in Browser

Visit: **http://127.0.0.1:5000**

---

# Usage Guide

## Starting a Session

1. **Configure Settings** (left sidebar):
   - **Max Questions**: 5-30 (default: 15)
   - **Confidence Threshold**: 0.5-0.95 (default: 0.75)
   - **Temperature**: 0-1 (default: 0.7)
   - **Top P**: 0-1 (default: 0.95)

2. **Click "Start New Session"**

3. **Answer Questions:**
   - Click the response buttons (recommended)
   - Or type custom answers in the text box
   - Press Enter or click "Send"

4. **Session Ends Automatically When:**
   - Confidence threshold reached
   - Max questions limit hit
   - Red flag detected

## Configuration Parameters Explained

### Thresholds & Limits

| Parameter | What It Does | Recommended Setting |
|-----------|--------------|-------------------|
| **Max Questions** | Hard stop - prevents infinite loops. Assessment ends when this many questions are reached. | 10-15 for quick triage, 20-30 for detailed intake |
| **Confidence Threshold** | Stops early when AI's diagnosis confidence reaches this level. Higher = more questions, more thorough. | 0.75 (balanced) or 0.85-0.90 (more thorough) |

### Model Parameters

| Parameter | What It Does | Recommended Setting |
|-----------|--------------|-------------------|
| **Temperature** | Controls AI randomness. Lower (0-0.3) = focused & consistent. Higher (0.7-1) = creative & varied. | 0.3-0.5 for medical (focused), 0.7-1.0 for conversational |
| **Top P** | Nucleus sampling. Limits to top P% probable words. Lower = more focused responses. | 0.9-0.95 (balanced) |
| **Max Tokens** | Maximum length of AI response in "tokens" (~4 characters). 500 = good for questions + buttons. | 500-1000 |

### System Prompt

Custom instructions that guide the AI's behavior. You can modify it to:
- Change question style
- Add specialty-specific questions
- Modify red flag rules
- Adjust response format

Click "Load Default Prompt" to restore original settings.

---

# How It Works

## Demo Mode vs. Real AI

### Demo Mode (No API Key)
```
User Input → App selects from pre-written questions → Shows buttons
```
- Questions are hardcoded in `app.py`
- Same flow every time
- Good for UI testing

### Real AI Mode (With API Key)
```
User Input → Sends to Azure OpenAI/OpenAI → AI generates context-aware question → Shows buttons
```
- Questions are dynamically generated
- Adapts to patient responses
- Real medical reasoning

## Response Flow

1. **AI Question** + **Clickable Buttons**
   ```
   "How severe is your pain?"
   [Mild (1-3)] [Moderate (4-6)] [Severe (7-10)]
   ```

2. **User Clicks Button**
   ```
   Click: "Moderate (4-6)"
   ```

3. **AI Generates Next Question** based on answer
   ```
   "Is the pain sharp, dull, burning, or pressure-like?"
   [Sharp] [Dull/Aching] [Burning] [Pressure/Heavy] [Other]
   ```

4. **Repeat** until confidence threshold or max questions reached

---

# API Endpoints

### Start Session
```http
POST /api/session/start
Content-Type: application/json

{
  "max_questions": 15,
  "confidence_threshold": 0.75,
  "temperature": 0.7,
  "top_p": 0.95,
  "max_tokens": 500,
  "system_prompt": "You are a medical assistant..."
}
```

**Response:**
```json
{
  "session_id": "uuid-string",
  "question": "What is your main concern?",
  "options": ["Chest pain", "Headache", "Other"],
  "question_number": 1
}
```

### Submit Answer
```http
POST /api/session/{session_id}/answer
Content-Type: application/json

{
  "question": "What is your main concern?",
  "answer": "Chest pain"
}
```

**Response:**
```json
{
  "next_question": "How long have you had this pain?",
  "options": ["Less than 1 day", "1-3 days", "More than 1 week"],
  "possible_diagnoses": [
    {"name": "Assessment in progress", "confidence": 0.2}
  ],
  "red_flag": false,
  "triage_level": "routine",
  "final": false,
  "question_number": 2
}
```

### Get Diagnosis
```http
GET /api/session/{session_id}/diagnosis
```

**Response:**
```json
{
  "diagnosis": {
    "primary_diagnosis": "Viral Upper Respiratory Infection",
    "confidence": 0.78,
    "triage_level": "routine",
    "recommendations": ["Rest and hydrate", "Monitor symptoms"],
    "disclaimer": "This is not medical advice..."
  }
}
```

---

# Database Schema

### `patient_sessions`
| Column | Type | Description |
|--------|------|-------------|
| id | UUID | Session identifier |
| created_at | DateTime | Session start time |
| is_active | Boolean | Active status |
| question_count | Integer | Number of questions asked |
| config | JSON | Session configuration |
| conversation_summary | Text | Summary of conversation |

### `patient_answers`
| Column | Type | Description |
|--------|------|-------------|
| id | Integer | Auto-increment ID |
| session_id | UUID | Reference to session |
| question | Text | Question text |
| answer | Text | Patient's answer |
| question_number | Integer | Question sequence |
| timestamp | DateTime | Answer time |

---

# Safety Features

1. **Hard Stop Limit**: Max questions threshold prevents infinite loops
2. **Confidence Threshold**: Stops early when AI is confident
3. **Red Flag Detection**: Immediate stop for emergency symptoms
4. **Medical Disclaimer**: Always displayed with results
5. **Structured Output**: AI forced to return JSON for safety
6. **Session Isolation**: Each session is independent

---

# Troubleshooting

### Server won't start

**Error:** `ModuleNotFoundError: No module named 'flask'`

**Solution:**
```bash
pip3 install -r requirements.txt
```

### API errors

**Error:** `Missing credentials. Please pass API key`

**Solution:** Check your `.env` file has correct credentials:
```bash
# Should NOT be "your_api_key_here"
AZURE_OPENAI_API_KEY=sk-actual-key-here
```

### Port already in use

**Error:** `Address already in use`

**Solution:** Kill the existing process or use a different port:
```bash
# Find and kill process on port 5000
lsof -ti:5000 | xargs kill -9

# Or use different port
python3 app.py
# Then edit port in app.py to 5001
```

### Demo mode questions are too simple

**Solution:** Configure Azure OpenAI or OpenAI API key for real AI responses (see Step 2 above).

---

# Medical Disclaimer

**⚠️ IMPORTANT:** This system is for informational and educational purposes only. It is NOT a substitute for professional medical advice, diagnosis, or treatment.

- Always seek the advice of your physician or qualified health provider
- Do not disregard professional medical advice based on this system
- If you have a medical emergency, call emergency services immediately
- This system may produce inaccurate or incomplete information

---

# Development Roadmap

### Phase 1 (Current MVP ✅)
- ✅ Basic Flask backend
- ✅ Azure OpenAI/OpenAI API integration
- ✅ Chat UI with clickable buttons
- ✅ SQLite database
- ✅ Configurable thresholds
- ✅ Demo mode

### Phase 2 (Future)
- [ ] PostgreSQL support
- [ ] Embedding-based question deduplication
- [ ] Structured symptom knowledge graph
- [ ] Enhanced red flag rules
- [ ] EHR integration

### Phase 3 (Future)
- [ ] Multi-language support
- [ ] Voice input
- [ ] Image upload for skin conditions
- [ ] Provider dashboard
- [ ] HIPAA compliance features

---

# Tech Stack

| Component | Technology |
|-----------|------------|
| **Backend** | Flask (Python 3.8+) |
| **Frontend** | HTML, CSS, JavaScript (Vanilla) |
| **AI** | Azure OpenAI / OpenAI API (GPT-4/GPT-3.5) |
| **Database** | SQLite (upgradable to PostgreSQL) |
| **AI SDK** | OpenAI Python SDK 1.12.0+ |

---

# License

This project is for educational purposes. Use at your own risk.

---

# Support

For issues or questions:
1. Check the Troubleshooting section above
2. Review the API endpoint documentation
3. Ensure your API credentials are correctly configured

**Built with ❤️ for better healthcare accessibility**
