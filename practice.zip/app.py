"""
Medical Symptom Intake & Triage System
Dynamic symptom checker with Azure OpenAI integration
"""

import os
import uuid
import json
from datetime import datetime
from flask import Flask, render_template, request, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from openai import AzureOpenAI

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')

# Database Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///symptom_intake.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Azure OpenAI Configuration
AZURE_OPENAI_API_KEY = os.environ.get('AZURE_OPENAI_API_KEY')
AZURE_OPENAI_ENDPOINT = os.environ.get('AZURE_OPENAI_ENDPOINT')
AZURE_OPENAI_DEPLOYMENT = os.environ.get('AZURE_OPENAI_DEPLOYMENT', 'gpt-4')
AZURE_OPENAI_API_VERSION = os.environ.get('AZURE_OPENAI_API_VERSION', '2024-02-15-preview')

# Initialize Azure OpenAI client (optional - for demo mode if not configured)
client = None
if AZURE_OPENAI_API_KEY and AZURE_OPENAI_ENDPOINT and AZURE_OPENAI_API_KEY != 'your_api_key_here':
    try:
        client = AzureOpenAI(
            api_key=AZURE_OPENAI_API_KEY,
            api_version=AZURE_OPENAI_API_VERSION,
            azure_endpoint=AZURE_OPENAI_ENDPOINT
        )
    except Exception as e:
        print(f"Warning: Could not initialize Azure OpenAI client: {e}")
        print("Running in DEMO mode - UI will work but AI responses will be mocked.")

# Default system prompt
DEFAULT_SYSTEM_PROMPT = """You are a senior board-certified internal medicine physician conducting a structured patient intake.

Your role:
- Ask ONE clear, focused question at a time
- Never repeat questions already asked
- Drill down based on patient answers
- Include severity, duration, and location questions as needed
- Check for red flags immediately
- Provide structured JSON output with clickable button options

IMPORTANT: Always provide 2-5 clickable response options that the patient can select from.
For severity questions: "Mild (1-3)", "Moderate (4-6)", "Severe (7-10)"
For yes/no questions: "Yes", "No"
For duration: "Less than 1 day", "1-3 days", "4-7 days", "More than 1 week"
For location: "Left side", "Right side", "Center", "All over"

Red flags that require IMMEDIATE stop:
- Chest pain with shortness of breath, sweating, or radiation to arm/jaw
- Severe headache with neurological symptoms
- Difficulty breathing
- Loss of consciousness
- Severe abdominal pain with rigidity

Return ONLY JSON in this format:
{
  "next_question": "question text",
  "options": ["Option 1", "Option 2", "Option 3", "Other"],
  "allow_custom_input": true,
  "possible_diagnoses": [{"name": "condition", "confidence": 0.0-1.0}],
  "red_flag": false,
  "triage_level": "routine"|"urgent"|"emergency",
  "final": false,
  "disclaimer": "medical disclaimer text"
}

Notes:
- "options" is REQUIRED - provide 2-5 clickable response choices
- "allow_custom_input" should be true if patients might need to type details
- Always include "Other" as an option when appropriate
- If asking about severity, use the scale: "Mild (1-3)", "Moderate (4-6)", "Severe (7-10)"

Stop asking questions when:
- Confidence >= threshold set by user
- Red flag detected
- Max questions reached"""


# Database Models
class PatientSession(db.Model):
    """Patient session tracking"""
    __tablename__ = 'patient_sessions'

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    question_count = db.Column(db.Integer, default=0)
    config = db.Column(db.JSON)  # Stores threshold, max_questions, etc.
    conversation_summary = db.Column(db.Text)


class PatientAnswer(db.Model):
    """Individual patient answers"""
    __tablename__ = 'patient_answers'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    session_id = db.Column(db.String(36), db.ForeignKey('patient_sessions.id'), nullable=False)
    question = db.Column(db.Text, nullable=False)
    answer = db.Column(db.Text, nullable=False)
    severity = db.Column(db.Integer)  # 1-10 scale
    question_number = db.Column(db.Integer)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)


# Routes
@app.route('/')
def index():
    """Render main chat interface"""
    return render_template('index.html')


@app.route('/api/config', methods=['GET'])
def get_default_config():
    """Get default configuration"""
    return jsonify({
        'max_questions': 15,
        'confidence_threshold': 0.75,
        'temperature': 0.7,
        'max_tokens': 500,
        'top_p': 0.95,
        'system_prompt': DEFAULT_SYSTEM_PROMPT
    })


@app.route('/api/session/start', methods=['POST'])
def start_session():
    """Start a new patient intake session"""
    data = request.get_json()

    # Create new session
    session_id = str(uuid.uuid4())

    patient_session = PatientSession(
        id=session_id,
        config={
            'max_questions': data.get('max_questions', 15),
            'confidence_threshold': data.get('confidence_threshold', 0.75),
            'temperature': data.get('temperature', 0.7),
            'max_tokens': data.get('max_tokens', 500),
            'top_p': data.get('top_p', 0.95),
            'system_prompt': data.get('system_prompt', DEFAULT_SYSTEM_PROMPT)
        }
    )
    db.session.add(patient_session)
    db.session.commit()

    # Generate initial greeting question
    config = patient_session.config
    initial_prompt = f"""{config['system_prompt']}

The patient is starting a new intake. Begin by asking about their chief complaint.
Return the JSON response as specified."""

    # Generate initial greeting question
    if client:
        # Use Azure OpenAI
        response = client.chat.completions.create(
            model=AZURE_OPENAI_DEPLOYMENT,
            messages=[
                {"role": "system", "content": initial_prompt},
                {"role": "user", "content": "I'd like to start a symptom assessment."}
            ],
            temperature=config['temperature'],
            max_tokens=config['max_tokens'],
            top_p=config['top_p']
        )
        result = json.loads(response.choices[0].message.content)
    else:
        # Demo mode - return mock response
        result = {
            "next_question": "Hello! I'm here to help assess your symptoms. What is your main concern or chief complaint today?",
            "options": ["Chest pain", "Headache", "Abdominal pain", "Fever", "Shortness of breath", "Other"],
            "allow_custom_input": True,
            "possible_diagnoses": [],
            "red_flag": False,
            "triage_level": "routine",
            "final": False
        }

    return jsonify({
        'session_id': session_id,
        'question': result.get('next_question'),
        'options': result.get('options', []),
        'allow_custom_input': result.get('allow_custom_input', True),
        'question_number': 1
    })


@app.route('/api/session/<session_id>/answer', methods=['POST'])
def submit_answer(session_id):
    """Submit patient answer and get next question"""
    data = request.get_json()

    patient_session = PatientSession.query.get(session_id)
    if not patient_session:
        return jsonify({'error': 'Session not found'}), 404

    # Save answer
    patient_answer = PatientAnswer(
        session_id=session_id,
        question=data.get('question'),
        answer=data.get('answer'),
        severity=data.get('severity'),
        question_number=patient_session.question_count + 1
    )
    db.session.add(patient_answer)

    # Get all previous answers for context
    previous_answers = PatientAnswer.query.filter_by(
        session_id=session_id
    ).order_by(PatientAnswer.question_number).all()

    # Build conversation context
    conversation = []
    for ans in previous_answers:
        conversation.append({"role": "assistant", "content": ans.question})
        conversation.append({"role": "user", "content": ans.answer})

    config = patient_session.config
    patient_session.question_count += 1

    # Check thresholds
    should_stop = False
    stop_reason = None

    if patient_session.question_count >= config['max_questions']:
        should_stop = True
        stop_reason = "max_questions_reached"

    # Build system prompt with context
    system_prompt = f"""{config['system_prompt']}

Session Context:
- Questions asked so far: {patient_session.question_count}
- Max questions allowed: {config['max_questions']}
- Confidence threshold to stop: {config['confidence_threshold']}

Previous questions asked (DO NOT repeat these):
{chr(10).join(f"- {ans.question}" for ans in previous_answers)}

Current patient answer: {data.get('answer')}

Based on this answer, determine the next question OR if confident enough, provide final diagnosis."""

    # Generate next question using AI or demo mode
    if client:
        response = client.chat.completions.create(
            model=AZURE_OPENAI_DEPLOYMENT,
            messages=[
                {"role": "system", "content": system_prompt},
                *conversation,
                {"role": "user", "content": data.get('answer')}
            ],
            temperature=config['temperature'],
            max_tokens=config['max_tokens'],
            top_p=config['top_p']
        )
        result = json.loads(response.choices[0].message.content)
    else:
        # Demo mode - return mock response based on answer
        answer_lower = data.get('answer', '').lower()

        # Demo: Detect chest pain for red flag demo
        if 'chest pain' in answer_lower and any(word in answer_lower for word in ['shortness', 'breath', 'sweat', 'radiat', 'jaw', 'arm']):
            result = {
                "next_question": None,
                "options": [],
                "possible_diagnoses": [{"name": "Possible Acute Coronary Syndrome", "confidence": 0.85}],
                "red_flag": True,
                "triage_level": "emergency",
                "final": True,
                "disclaimer": "This may be a medical emergency. Please seek immediate care."
            }
        # Demo: Progress through mock questions
        elif patient_session.question_count >= config['max_questions']:
            result = {
                "next_question": None,
                "options": [],
                "possible_diagnoses": [{"name": "Viral Upper Respiratory Infection", "confidence": 0.78}],
                "red_flag": False,
                "triage_level": "routine",
                "final": True,
                "disclaimer": "This is a demo diagnosis. Configure Azure OpenAI for real AI responses."
            }
        else:
            # Demo questions with corresponding options
            demo_flow = [
                {
                    "question": "How long have you been experiencing these symptoms?",
                    "options": ["Less than 1 day", "1-3 days", "4-7 days", "More than 1 week"]
                },
                {
                    "question": "How would you describe the severity?",
                    "options": ["Mild (1-3)", "Moderate (4-6)", "Severe (7-10)"]
                },
                {
                    "question": "Is the pain sharp, dull, burning, or pressure-like?",
                    "options": ["Sharp", "Dull/Aching", "Burning", "Pressure/Heavy", "Other"]
                },
                {
                    "question": "Does anything make the symptoms better or worse?",
                    "options": ["Movement makes it worse", "Rest helps", "Eating affects it", "Breathing affects it", "Nothing helps"]
                },
                {
                    "question": "Do you have any other associated symptoms?",
                    "options": ["Fever", "Nausea", "Fatigue", "Dizziness", "None of these"]
                }
            ]
            idx = min(patient_session.question_count - 1, len(demo_flow) - 1)
            flow = demo_flow[idx]
            result = {
                "next_question": flow["question"],
                "options": flow["options"],
                "allow_custom_input": True,
                "possible_diagnoses": [{"name": "Assessment in progress", "confidence": 0.2 * patient_session.question_count}],
                "red_flag": False,
                "triage_level": "routine",
                "final": False
            }

    # Check red flags
    if result.get('red_flag') or result.get('triage_level') == 'emergency':
        should_stop = True
        stop_reason = "red_flag_detected"

    # Check confidence threshold
    diagnoses = result.get('possible_diagnoses', [])
    if diagnoses and max(d.get('confidence', 0) for d in diagnoses) >= config['confidence_threshold']:
        should_stop = True
        stop_reason = "confidence_threshold_reached"

    # Check if AI marked as final
    if result.get('final'):
        should_stop = True
        stop_reason = "ai_decision"

    db.session.commit()

    return jsonify({
        'next_question': result.get('next_question'),
        'options': result.get('options', []),
        'allow_custom_input': result.get('allow_custom_input', True),
        'possible_diagnoses': diagnoses,
        'red_flag': result.get('red_flag', False),
        'triage_level': result.get('triage_level', 'routine'),
        'final': should_stop,
        'stop_reason': stop_reason,
        'disclaimer': result.get('disclaimer'),
        'question_number': patient_session.question_count + 1
    })


@app.route('/api/session/<session_id>/diagnosis', methods=['GET'])
def get_diagnosis(session_id):
    """Get final diagnosis summary"""
    patient_session = PatientSession.query.get(session_id)
    if not patient_session:
        return jsonify({'error': 'Session not found'}), 404

    answers = PatientAnswer.query.filter_by(
        session_id=session_id
    ).order_by(PatientAnswer.question_number).all()

    config = patient_session.config

    # Generate final summary
    summary_prompt = f"""{config['system_prompt']}

Based on the following patient intake, provide a final summary:

{chr(10).join(f"Q{i+1}: {ans.question}\nA: {ans.answer}" for i, ans in enumerate(answers))}

Return JSON:
{{
  "primary_diagnosis": "most likely condition",
  "differential_diagnoses": ["other possibilities"],
  "confidence": 0.0-1.0,
  "triage_level": "routine"|"urgent"|"emergency",
  "recommendations": ["next steps"],
  "red_flags": ["any concerning symptoms"],
  "disclaimer": "This is not medical advice..."
}}"""

    # Generate final summary using AI or demo mode
    if client:
        response = client.chat.completions.create(
            model=AZURE_OPENAI_DEPLOYMENT,
            messages=[
                {"role": "system", "content": summary_prompt},
                {"role": "user", "content": "Please provide the final diagnosis summary."}
            ],
            temperature=0.3,
            max_tokens=1000
        )
        result = json.loads(response.choices[0].message.content)
    else:
        # Demo mode - return mock diagnosis
        result = {
            "primary_diagnosis": "Viral Upper Respiratory Infection (Demo)",
            "differential_diagnoses": ["Seasonal Allergies", "Bacterial Pharyngitis"],
            "confidence": 0.72,
            "triage_level": "routine",
            "recommendations": [
                "Rest and stay hydrated",
                "Over-the-counter symptom relief",
                "Monitor for worsening symptoms",
                "Follow up with primary care if not improved in 3-5 days"
            ],
            "red_flags": [],
            "disclaimer": "This is a DEMO diagnosis. Configure Azure OpenAI credentials in .env for real AI-powered assessments. This is not medical advice."
        }

    return jsonify({
        'session_id': session_id,
        'question_count': patient_session.question_count,
        'answers': [{
            'question': a.question,
            'answer': a.answer,
            'severity': a.severity
        } for a in answers],
        'diagnosis': result
    })


# Initialize database
with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True, port=5000)
