# 🚀 Quick Setup Guide - Healthcare Audit Tool

## ⚡ Fast Start (5 minutes)

### Option 1: Using Makefile (Recommended)
```bash
# Show all available commands
make help

# Full setup and start (install dependencies and run)
make start

# Or just run without installing dependencies
make run
```

### Option 2: Manual setup
```bash
# Install dependencies
pip install -r requirements.txt

# Run the application
python app.py
```

## 🌐 Access the Application

Once started, open your browser and navigate to:
**http://localhost:7000**

## 📊 Sample Data Included

The application comes with 2 sample accounts:

### Account 12345 - John Smith
- **6 ICD Codes** with 67% accuracy
- **Principal Diagnosis**: Sepsis (A41.9)
- **Conditions**: Hypertension, Diabetes, Heart Failure, Chest Pain, Chemotherapy

### Account 23456 - Sarah Johnson  
- **5 ICD Codes** with 60% accuracy
- **Principal Diagnosis**: Acute MI (I21.9)
- **Conditions**: CAD, Lipid Disorders, Medication Therapy, Chemotherapy

## 🎯 How to Use

1. **Dashboard**: View all accounts and statistics
2. **Review**: Click on any account to review ICD codes
3. **Compare**: See human-coded vs LLM-generated codes side-by-side
4. **Feedback**: Accept/reject codes and add comments
5. **Submit**: Save your feedback
6. **Validation**: View all submitted feedback in the validation dashboard

## 🔧 Features Demonstrated

- ✅ **Eye-friendly dark theme** with green accents
- ✅ **Responsive design** for all screen sizes
- ✅ **Real-time feedback** submission
- ✅ **Comprehensive logging** system
- ✅ **Sample data** with realistic medical scenarios
- ✅ **Validation dashboard** with statistics
- ✅ **Random chart selection** functionality

## 🛠️ Troubleshooting

### Port already in use
The Makefile automatically handles this, but if you're running manually:
```bash
# Kill any process using port 7000
lsof -ti:7000 | xargs kill -9
```

### Python not found
```bash
# Install Python 3
brew install python3  # macOS
sudo apt install python3  # Ubuntu
```

### Dependencies not installing
```bash
# Upgrade pip
pip install --upgrade pip

# Install with verbose output
pip install -r requirements.txt -v
```

## 📝 Next Steps

1. **Customize Data**: Update `SAMPLE_ACCOUNTS` in `app.py`
2. **Add Authentication**: Implement user login system
3. **Database Integration**: Connect to PostgreSQL/MongoDB
4. **Export Features**: Add PDF/Excel report generation
5. **Advanced Analytics**: Implement ML-based insights

## 🆘 Need Help?

- Check the main `README.md` for detailed documentation
- Review the code comments in `app.py`
- Check the logs in `audit_tool.log`
- Create an issue in the repository

---

**🎉 You're all set! The Healthcare Audit Tool is ready to use.** 