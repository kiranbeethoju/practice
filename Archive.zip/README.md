# Healthcare Audit Tool

A comprehensive healthcare audit tool built with Python Flask and Bootstrap 5, featuring a dark theme optimized for eye comfort and extended usability.

## Features

- **User Authentication**: Secure login system with auditor credentials stored in Excel file
- **Auditor Management**: Support for multiple auditors with team assignments
- **Session Management**: Secure session handling with automatic logout
- **Dark Theme**: Eye-friendly black and green color scheme with low blue light emission
- **Account Management**: Sample accounts with ground truth and LLM output comparison
- **Document Preview**: Modal-based document viewing with color-coded document types
- **Feedback System**: Accept/Reject functionality with structured feedback storage linked to auditor names
- **Responsive Design**: Bootstrap 5-based responsive interface
- **Logging**: Comprehensive logging system for audit trails
- **Excel Integration**: Dynamic document loading from Excel files
- **Audit Time Tracking**: Monitor auditor productivity by tracking time spent on each account review

## Recent Updates

### Latest Features (Latest Update)
- **NEW: Real Data Only - No Sample Accounts**:
  - **Document Loading**: Fixed to use `combined_content` column from `audited_accounts_129.xlsx`
  - **Data Validation**: Only loads accounts that have real document content and meaningful statistics
  - **Sample Prevention**: Removed all fallback sample content - system now skips accounts without real data
  - **Quality Control**: Accounts are only created if they have documents AND (SDX data OR PDX data)
  - **Enhanced Logging**: Detailed logging shows which accounts are loaded vs skipped with reasons
- **NEW: Enhanced Data File Support**:
  - **Updated CSV Loading**: Now supports both new (`pdx_gt_new.csv`, `sdx_gt_new.csv`) and legacy (`pdx_gt.csv`, `sdx_gt.csv`) file formats
  - **Enhanced Data Structure**: New files include additional fields like `icd_term`, `ccmcc`, `SOI`, `ROM` for richer data analysis
  - **Flexible Column Mapping**: Automatically detects and handles different column naming conventions
  - **Backward Compatibility**: Falls back to old file format if new files are not available
  - **Real Account Data**: System now uses actual account data instead of sample accounts
  - **Improved Logging**: Enhanced logging to track which files are loaded and their structure
- **NEW: Audit Time Tracking System**:
  - **Automatic Time Capture**: Tracks time from when auditor opens an account to when they submit feedback
  - **Session-Based Tracking**: Uses Flask sessions to track audit start and end times
  - **Duration Calculation**: Automatically calculates audit duration in minutes
  - **Audit Times Dashboard**: New `/audit-times` page showing comprehensive audit time statistics
  - **Auditor Performance Metrics**: Shows total audits, average duration, fastest/slowest audits per auditor
  - **Detailed Audit Records**: Complete audit history with account number, auditor, start/end times, and duration
  - **Excel Data Storage**: All audit time data stored in `audit_times.xlsx` for analysis
  - **Real-Time Statistics**: Live calculation of audit performance metrics
  - **Navigation Integration**: Added "Audit Times" link in main navigation for easy access
  - **Dark Theme Consistency**: Audit times dashboard follows the same dark theme design
  - **Performance Analytics**: Auditor comparison showing count, mean, min, and max duration per auditor
- **NEW: Auditor Login System**:
  - **Secure Authentication**: Login system with credentials stored in `logins.xlsx`
  - **Multiple Auditors**: Support for multiple auditors with username, password, name, and team
  - **Session Management**: Secure session handling with automatic logout functionality
  - **Protected Routes**: All audit pages require authentication
  - **User Information Display**: Shows logged-in auditor name and team in navigation
  - **Auditor-Linked Feedback**: All feedback submissions are linked to the logged-in auditor's name
  - **Demo Credentials**: Pre-configured demo accounts for testing (admin/admin123, auditor1/pass123, etc.)
  - **Login Page**: Modern, responsive login interface with dark theme
  - **Logout Functionality**: Secure logout with session clearing
- **Fixed Completed Review Data Table Issues**:
  - **FIXED: Added Type Column** - Completed Review Data table now shows PDX, ADX, SDX, and ICD feedback types
  - **FIXED: Added CC/MCC Column** - Completed Review Data table now includes CC/MCC information from Flagged ICDs table
  - **FIXED: CC/MCC Mapping** - Feedback submission now automatically maps CC/MCC information from parsed data to feedback entries
  - **FIXED: Type Detection Logic** - Fixed TYPE column to show correct types (PDX/ADX/SDX) based on parsed data mapping instead of feedback fields
  - **FIXED: Feedback Display** - Improved feedback column to properly show actual feedback values instead of "nan"
  - **FIXED: Enhanced Feedback Display** - Type column uses color-coded badges to distinguish between different feedback types
  - **FIXED: Feedback Type Detection** - Updated get_submitted_feedback filter to properly detect and categorize feedback by type
  - **NEW: General Feedback Section** - Added separate section showing PDX, ADX, and SDX feedback values
  - **REMOVED: Search Features** - Removed floating search bar and search results panel from both lookup and review pages due to functionality issues
  - **FIXED: Text Colors** - Added comprehensive text color fixes to ensure all text is white and visible on dark background, with proper contrast for buttons and badges
  - **NEW: Color-Coded Type Badges** - PDX Feedback (blue), ADX Feedback (yellow), SDX Feedback (cyan), ICD Feedback (gray)
  - **NEW: CC/MCC Badges** - CC (yellow badge), MCC (red badge) in Completed Review Data table
  - **FIXED: Badge Text Colors** - Added CSS rules to ensure CC, MCC, and other badges display with proper text colors (black text on warning badges, white text on danger/secondary badges)
  - **NEW: Accept/Reject Button Highlighting** - Added thick color highlighting with glow effects, scaling, and thicker borders when Accept/Reject buttons are selected
  - **NEW: CC/MCC Statistics Table** - Added new statistics table showing count comparison of CC/MCC between ground truth SDX and LLM extracted data, displayed next to existing statistics in both lookup and review pages
  - **ENHANCED: Ground Truth SDX Data** - Added CC/MCC column to SDX Ground Truth data table, showing actual CC/MCC values for each SDX code
  - **UPDATED: CSV Data Structure** - Enhanced sdx_gt.csv to include cc_mcc column with CC/MCC information for each SDX code
- **Fixed Data Loading and Display Issues**:
  - **FIXED: Updated all file paths** to use correct directory `/home/nlpadmin/conc_ip_coding/DS_IP_CODING_ACCELERATOR/IP_Audit_Tool_v5`
  - **FIXED: Added Flagged ICDs table** - displays combination code review data just above feedback section
  - **FIXED: LLM PDX extraction** - now properly extracts from A. Coded Diagnoses Table
  - **FIXED: Table styling** - enforced dark theme with white text on all tables
  - **FIXED: Document search functionality** - added complete search implementation with highlighting
  - **FIXED: Coded ICD extraction** - improved extraction from parsed data
  - **NEW: SDX Match Column** - added to Review and Feedback table showing SDX Match/Mismatch/Specificity Issue
  - **NEW: Removed unwanted tables** - removed "Coded vs LLM Comparison" and "A. Coded Diagnoses Table" from top
  - **NEW: Fixed search popup** - improved close functionality and search experience
  - **NEW: LLM Mapping** - now properly maps LLM codes against actual SDX_GT codes for each account
  - **NEW: Multiple ADX Support** - now handles multiple ADX codes with same ICD independently
  - **NEW: Individual Record Storage** - each feedback entry stored separately with unique identifiers
  - **NEW: Fixed PDX Value Swapping** - corrected LLM PDX and Coded PDX assignment
- **Data Source Structure**: 
  - **FIXED: Documents loaded** from `audited_accounts_129.xlsx` (document source)
  - **FIXED: Extracted codes loaded** from `parsed_results_new_v6.xlsx` (primary data source)
  - **FIXED: LLM mapping** - now properly maps all parsed codes against ground truth
  - **FIXED: Document preview** - added working document preview modal
  - **FIXED: Document search** - restored full search functionality
- **Array of Objects Parsing**:
- **Array of Objects Parsing**: 
  - **NEW: Added parsing functionality** for array of objects from Excel files
  - **NEW: B. Coded Procedures Table** - displays parsed procedure data in separate columns
  - **NEW: C. MS-DRG Assignment and Rationale** - shows DRG assignments with reasoning
  - **NEW: CSV Data Integration** - loads and displays PDX/SDX data from CSV files
  - **NEW: Dynamic Data Parsing** - automatically parses string representations of arrays into structured objects
  - **NEW: Enhanced Data Display** - separate tables for procedures, DRG assignments, and ground truth data
- **Enhanced Search Functionality**: 
  - Search now works with any number of characters (1, 2, 3, or more)
  - Removed the 3-character minimum requirement for search activation
  - Continuous highlighting updates as you type longer search terms
  - **NEW: Added debounce mechanism** to prevent excessive search calls (300ms delay)
  - **NEW: Fixed form interference** - search no longer interferes with form submissions
  - **NEW: Smart search exclusion** - search excludes form inputs, buttons, and search containers
  - **NEW: Auto-clear search** when forms are submitted or when typing in other form fields
  - **NEW: Text-only highlighting** - search highlights use yellow text color instead of background colors
  - **NEW: Accessibility improvements** - fixed modal focus issues and removed aria-hidden conflicts
- **Comprehensive Font Color Fixes**:
  - Fixed all black text issues on the main dashboard
  - Added extensive CSS rules to ensure all text is white or yellow on dark backgrounds
  - Applied color fixes to cards, card bodies, stats cards, and account cards
  - Override Bootstrap text utilities to maintain consistent coloring

### Previous Features
- **Advanced Global Search**: Movable search interface with clear button and drag functionality
- **Auto-Opening Document Modal**: Automatically opens document modal when searching for document content
- **Document Term Highlighting**: Matching search terms are highlighted in yellow within documents
- **Document Preview**: Modal window showing 4 document types (H&P, ED Summary, Consult Note, Discharge Summary) with different background colors
- **Excel Data Loading**: Dynamic loading of document content from `documents.xlsx` file
- **Template Error Fixes**: Resolved Jinja2 template errors and data structure issues
- **UI Improvements**: Collapse/expand functionality for sidebars, improved color scheme
- **Search Enhancements**: Global search, text selection search, and highlighting improvements
- **Color Fixes**: Comprehensive fixes for text colors across all pages
- **Icon Removal**: Replaced checkmark/cross icons with "Completed"/"Pending" text
- **Table Color Fixes**: Fixed table colors in comparison sections
- **Accept/Reject Buttons**: Interactive buttons with proper visual states

## Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   make install
   ```
3. Run the application:
   ```bash
   make run
   ```

## Usage

- **Main Dashboard**: View account overview and statistics
- **Review Page**: Detailed account review with document comparison
- **Validation Dashboard**: View feedback and validation results
- **Global Search**: Use the movable search bar to find any text
- **Document Preview**: Click "Preview Documents" to view all document types
- **Text Selection**: Select any text to search within documents

## Recent Updates

### Major Features Added:
- **Complete Account Separation**: Implemented pending vs completed account system with dedicated pages
- **Dynamic Data Loading**: All review data now loaded from Excel files instead of hardcoded values
- **Feedback Storage**: Latest feedback saved to separate Excel sheet (`feedback_data.xlsx`) - only one feedback per ICD code
- **Account Feedback**: Added account feedback page showing latest submitted feedback for each account
- **Feedback Display**: Enhanced feedback submission with immediate display of submitted feedback in success modal
- **Existing Feedback**: Review pages now show existing feedback when available
- **Document Preview Modal**: Added preview button to show 4 document types in scrollable modal
- **Advanced Search System**: Comprehensive search with dedicated results panel and navigation
- **Template Error Fix**: Resolved Jinja2 template issues in validation dashboard
- **UI Improvements**: Enhanced dark theme with proper color coding and eye-friendly design

### New Excel Files Structure (4 Files Required):

#### 1. `parsed_results_new_v6.xlsx` (EXTRACTED CODES - PRIMARY DATA)
- **Purpose**: Primary source file containing parsed account data and extracted codes
- **Columns**: `acct_number`, `A. Coded Diagnoses Table`, `B. Coded Procedures Table`, `C. MS-DRG Assignment and Rationale`, `A. Coded Diagnoses Table - Combination Code Review`
- **Usage**: Primary source for account data, diagnoses, procedures, and DRG assignments
- **Data Handling**: Contains structured arrays of diagnoses, procedures, and DRG information

#### 2. `audited_accounts_129.xlsx` (DOCUMENTS - DOCUMENT SOURCE)
- **Purpose**: Source file containing account documents and information
- **Columns**: `ACCOUNT_NUMBER`, `FAC_NAME`, `ADM_DATETIME`, `DISCH_DATETIME`, `document`, `UPDATE_DATE`, `TRANS_DATE`, `EDIT_DATE`, `DAY_DIFF`
- **Usage**: Source for account documents and additional account data
- **Document Handling**: Single `document` column contains all document content

#### 2. `parsed_results_new_v6.xlsx` (PRIMARY DATA)
- **Purpose**: Contains array of objects data for diagnoses, procedures and DRG assignments
- **Columns**: `acct_number`, `A. Coded Diagnoses Table`, `B. Coded Procedures Table`, `C. MS-DRG Assignment and Rationale`
- **Usage**: Powers ALL tables including A. Coded Diagnoses Table, B. Coded Procedures Table, C. MS-DRG Assignment sections, AND Review and Feedback table
- **A. Coded Diagnoses Table Structure**: Array of dictionaries with:
  - `Type`: PDX, ADX, or SDX
  - `ICD-10-CM Code`: The diagnosis code
  - `Diagnosis/Condition`: Description of the diagnosis
  - `CC/MCC`: Complication/Comorbidity or Major Complication/Comorbidity indicator
  - `POA`: Present On Admission status
  - `Supporting Documentation & Location`: Documentation references
  - `Coding Clinic/Guideline Reference`: Coding guidelines

#### 3. `pdx_gt.csv` and `sdx_gt.csv`
- **Purpose**: Ground truth data for PDX and SDX codes
- **Columns**: `ICD_CODE`, `pat_enc_id`, `acct_number`
- **Usage**: Powers the "Coded vs. LLM Comparison" table by providing the base ICD codes, which are then enriched with descriptions from the parsed diagnoses data

#### 5. `feedback_data.xlsx` (Output File)
- **Purpose**: Stores latest submitted feedback (accept/reject decisions and comments)
- **Columns**: `account_number`, `icd_code`, `accept_reject`, `feedback_comment`, `reviewer`, `timestamp`
- **Usage**: Latest feedback storage - only one feedback per ICD code per account

#### 6. `documents.xlsx` (Optional Fallback)
- **Purpose**: Fallback document source if `audited_accounts_26.xlsx` is not available
- **Columns**: `account_number`, `document_type`, `document_content`
- **Usage**: Powers the document preview modal (only used if primary file not found)

## Project Structure

- `app.py`: Main Flask application with dynamic Excel data loading
- `templates/`: HTML templates (index.html, review.html, validation.html, completed.html, account_history.html)
- `static/`: Static assets (CSS, JS, favicon)
- `icd_review_data.xlsx`: ICD codes for review with reference data
- `coded_vs_llm_comparison.xlsx`: Coded vs LLM comparison data
- `feedback_data.xlsx`: Submitted feedback storage
- `documents.xlsx`: Document content for preview
- `structured_output/`: Ground truth data
- `validation/`: Legacy feedback data
- `Makefile`: Project management commands

## Available Commands

- `make install`: Install dependencies
- `make run`: Start the application
- `make test`: Run tests
- `make clean`: Clean temporary files
- `make backup`: Create backup
- `make restore`: Restore from backup
- `make status`: Check application status
- `make kill-port`: Kill processes using the port
- `make force-kill-port`: Force kill processes using the port

## Technical Details

- **Backend**: Python Flask
- **Frontend**: Bootstrap 5, Font Awesome
- **Data Storage**: JSON files, Excel integration
- **Logging**: Python logging module
- **Port**: 8200 (configurable in Makefile)
- **Theme**: Dark mode with green accents 