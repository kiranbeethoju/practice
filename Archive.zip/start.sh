#!/bin/bash

# Healthcare Audit Tool Startup Script

echo "🏥 Starting Healthcare Audit Tool..."
echo "=================================="

# Kill any process using port 7000
echo "🔪 Checking for processes using port 7000..."
if lsof -ti:7000 &> /dev/null; then
    echo "   Found process(es) using port 7000. Killing them..."
    lsof -ti:7000 | xargs kill -9
    sleep 2
    echo "   ✅ Port 7000 is now free."
else
    echo "   ✅ Port 7000 is available."
fi

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3.8 or higher."
    exit 1
fi

# Check if pip is installed
if ! command -v pip3 &> /dev/null; then
    echo "❌ pip3 is not installed. Please install pip."
    exit 1
fi

# Install dependencies if requirements.txt exists
if [ -f "requirements.txt" ]; then
    echo "📦 Installing dependencies..."
    pip3 install -r requirements.txt
    if [ $? -ne 0 ]; then
        echo "❌ Failed to install dependencies."
        exit 1
    fi
    echo "✅ Dependencies installed successfully."
else
    echo "⚠️  requirements.txt not found. Skipping dependency installation."
fi

# Create necessary directories
echo "📁 Creating necessary directories..."
mkdir -p static templates structured_output validation logs

# Start the Flask application
echo "🚀 Starting Flask application..."
echo "🌐 The application will be available at: http://localhost:7000"
echo "📝 Logs will be written to: audit_tool.log"
echo ""
echo "Press Ctrl+C to stop the application."
echo ""

# Run the Flask application
python3 app.py 